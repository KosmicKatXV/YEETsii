# MIPS-Pipelined-Datapath
#### To Contact Me Click [Here](http://youssufradi.github.io/)
The goal of this project is to implement a low-level cycle-accurate pipelined MIPS datapath simulator. Simulating the datapath includes simulating all of its storage components (register file, memories, and pipeline registers) and all of its control signals.
